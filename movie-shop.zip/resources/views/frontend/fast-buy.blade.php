<div class="grid grid-cols-2 justify-center py-5 border-b border-gray-800 ">
    <div class="text-2xl text-center text-red-500 my-auto">
        Fast Buy Here
    </div>
    <div class="grid grid-rows-2">
        <div class="grid grid-cols-2">
            <div class="text-sm text-blue-500 ">
                <select class="bg-gray-800 rounded-full w-1/3" name="" id="">
                    <option value="">Choose Film</option>
                    <option value="">Tiệc trăng máu</option>
                </select>
            </div>
            <div class="text-sm text-blue-500">
                <select class="bg-gray-800 rounded-full w-1/3" name="" id="">
                    <option value="">Choose Day</option>
                    <option value="">Tiệc trăng máu</option>
                </select>
            </div>
        </div>
        <div class="grid grid-cols-2">
            <div class="text-sm text-blue-500 mt-2">
                <select class="bg-gray-800 rounded-full w-1/3" name="" id="">
                    <option value="">Choose Theater</option>
                    <option value="">Tiệc trăng máu</option>
                </select>
            </div>
            <div class="text-sm text-blue-500 mt-2">
                <select class="bg-gray-800 rounded-full w-1/3" name="" id="">
                    <option value="">Choose Time</option>
                    <option value="">Tiệc trăng máu</option>
                </select>
            </div>
        </div>
    </div>
</div>