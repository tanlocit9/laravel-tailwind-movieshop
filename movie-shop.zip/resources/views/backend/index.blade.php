<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">  
  <link rel="shortcut icon" href="/backend/img/fav.png" type="image/x-icon">  
  <link rel="stylesheet" href="https://kit-pro.fontawesome.com/releases/v5.12.1/css/pro.min.css">
  <link rel="stylesheet" type="text/css" href="backend/css/style.css">  
  <title>Welcome To Cleopatra</title>
</head>
<body class="bg-gray-800">
<!-- start navbar -->
<div class="md:fixed md:w-full md:top-0 md:z-20 flex flex-row flex-wrap items-center bg-gray-800 p-6 border-b border-gray-300">
    <!-- logo -->
    <div class="flex-none w-56 flex flex-row items-center">
    <svg class="w-32 text-red-500" viewBox="0 0 96 24" fill="none"><path d="M18 4l2 4h-3l-2-4h-2l2 4h-3l-2-4H8l2 4H7L5 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V4h-4zM35.568 7.047l2.557 7.219 2.543-7.22h2.693V17h-2.057v-2.72l.205-4.697L38.822 17h-1.408l-2.68-7.41.206 4.69V17h-2.051V7.047h2.68zm9.147 6.186c0-.733.141-1.387.424-1.962a3.108 3.108 0 011.216-1.333c.534-.314 1.151-.471 1.853-.471.998 0 1.812.305 2.44.916.634.61.987 1.44 1.06 2.488l.014.506c0 1.135-.317 2.046-.95 2.734-.634.684-1.484 1.026-2.55 1.026-1.067 0-1.919-.342-2.557-1.026-.633-.683-.95-1.613-.95-2.789v-.089zm1.975.144c0 .702.133 1.24.397 1.613.264.37.642.554 1.135.554.478 0 .852-.182 1.12-.547.27-.37.404-.957.404-1.764 0-.688-.134-1.221-.403-1.6-.27-.377-.647-.567-1.135-.567-.483 0-.857.19-1.121.568-.264.373-.397.954-.397 1.743zm8.908 1.21l1.374-4.983h2.064L56.541 17h-1.887L52.16 9.604h2.065l1.374 4.983zM61.996 17h-1.982V9.604h1.982V17zm-2.099-9.31c0-.297.098-.54.294-.732.2-.191.472-.287.814-.287.337 0 .606.096.806.287.201.191.301.435.301.731 0 .301-.102.547-.307.739-.2.191-.467.287-.8.287s-.602-.096-.807-.287a.975.975 0 01-.3-.739zm7.137 9.447c-1.085 0-1.969-.333-2.652-.998-.68-.666-1.019-1.552-1.019-2.66v-.19c0-.744.144-1.407.43-1.99a3.143 3.143 0 011.218-1.354c.528-.319 1.13-.478 1.804-.478 1.012 0 1.807.319 2.386.957.584.638.875 1.543.875 2.714v.806h-4.71c.064.483.255.87.574 1.162.324.292.732.438 1.224.438.761 0 1.356-.276 1.784-.827l.97 1.087a2.99 2.99 0 01-1.202.984 3.98 3.98 0 01-1.682.349zm-.225-6.07c-.392 0-.711.132-.957.396-.242.264-.397.643-.465 1.135h2.748v-.158c-.01-.437-.128-.774-.356-1.011-.228-.242-.551-.363-.97-.363zm10.144 3.882h-3.596L72.674 17h-2.18l3.704-9.953h1.9L79.825 17h-2.18l-.69-2.05zm-3.042-1.66H76.4l-1.25-3.726-1.238 3.725zm13.043.081c0 1.14-.26 2.053-.78 2.741-.514.684-1.211 1.026-2.091 1.026-.747 0-1.351-.26-1.811-.78v3.487h-1.976V9.604h1.832l.068.724c.479-.574 1.103-.861 1.873-.861.912 0 1.62.337 2.126 1.011.506.675.76 1.605.76 2.79v.102zm-1.975-.143c0-.689-.123-1.22-.37-1.593-.241-.374-.594-.56-1.06-.56-.619 0-1.045.236-1.278.71v3.028c.242.488.673.732 1.293.732.943 0 1.415-.773 1.415-2.317zm9.864.143c0 1.14-.26 2.053-.78 2.741-.514.684-1.212 1.026-2.091 1.026-.748 0-1.352-.26-1.812-.78v3.487h-1.975V9.604h1.832l.068.724c.479-.574 1.103-.861 1.873-.861.912 0 1.62.337 2.126 1.011.506.675.759 1.605.759 2.79v.102zm-1.976-.143c0-.689-.123-1.22-.369-1.593-.242-.374-.595-.56-1.06-.56-.62 0-1.045.236-1.278.71v3.028c.242.488.672.732 1.292.732.944 0 1.415-.773 1.415-2.317z" fill="#fff"/></svg>
      <strong class="capitalize ml-1 flex-1">cleopatra</strong>

      <button id="sliderBtn" class="flex-none text-right text-gray-900 hidden md:block">
        <i class="fad fa-list-ul"></i>
      </button>
    </div>

    <!-- end logo -->   
    <!-- navbar content toggle -->
    <button id="navbarToggle" class="hidden md:block md:fixed right-0 mr-6">
      <i class="fad fa-chevron-double-down"></i>
    </button>
    <!-- end navbar content toggle -->

    <!-- navbar content -->
    <div id="navbar" class="animated md:hidden md:fixed md:top-0 md:w-full md:left-0 md:mt-16 md:border-t md:border-b md:border-gray-200 md:p-10 md:bg-white flex-1 pl-3 flex flex-row flex-wrap justify-between items-center md:flex-col md:items-center">
      <!-- left -->
      <div class="text-gray-600 md:w-full md:flex md:flex-row md:justify-evenly md:pb-10 md:mb-10 md:border-b md:border-gray-200">
        {{-- <a class="mr-2 transition duration-500 ease-in-out hover:text-gray-900" href="#" title="email"><i class="fad fa-envelope-open-text"></i></a>        
        <a class="mr-2 transition duration-500 ease-in-out hover:text-gray-900" href="#" title="email"><i class="fad fa-comments-alt"></i></a>        
        <a class="mr-2 transition duration-500 ease-in-out hover:text-gray-900" href="#" title="email"><i class="fad fa-check-circle"></i></a>        
        <a class="mr-2 transition duration-500 ease-in-out hover:text-gray-900" href="#" title="email"><i class="fad fa-calendar-exclamation"></i></a>         --}}
      </div>
      <!-- end left -->      

      <!-- right -->
      <div class="flex flex-row-reverse items-center right-0"> 

        <!-- user -->
        <div class="dropdown relative md:static">

          <button class="menu-btn focus:outline-none focus:shadow-outline flex flex-wrap items-center">
            <div class="w-8 h-8 overflow-hidden rounded-full">
              <img class="w-full h-full object-cover" src="{{asset('backend/img/user.svg')}}" >
            </div> 

            <div class="ml-2 capitalize flex ">
              <h1 class="text-sm text-gray-800 font-semibold m-0 p-0 leading-none">{{Auth::user()->name}}</h1>
              <i class="fad fa-chevron-down ml-2 text-xs leading-none"></i>
            </div>                        
          </button>

          <button class="hidden fix ed top-0 left-0 z-10 w-full h-full menu-overflow"></button>

          <div class="text-gray-500 menu hidden md:mt-10 md:w-full rounded bg-white shadow-md absolute z-20 right-0 w-40 mt-5 py-2 animated faster">
            <!-- item -->
            <a class="px-4 py-2 block capitalize font-medium text-sm tracking-wide bg-white hover:bg-gray-200 hover:text-gray-900 transition-all duration-300 ease-in-out" href="#">
              <i class="fad fa-user-edit text-xs mr-1"></i> 
              edit my profile
            </a>     
            <!-- end item -->
            <!-- item -->
            <a class="px-4 py-2 block capitalize font-medium text-sm tracking-wide bg-white hover:bg-gray-200 hover:text-gray-900 transition-all duration-300 ease-in-out" href="#">
              <i class="fad fa-inbox-in text-xs mr-1"></i> 
              my inbox
            </a>     
            <!-- end item -->
            <!-- item -->
            <a class="px-4 py-2 block capitalize font-medium text-sm tracking-wide bg-white hover:bg-gray-200 hover:text-gray-900 transition-all duration-300 ease-in-out" href="#">
              <i class="fad fa-badge-check text-xs mr-1"></i> 
              tasks
            </a>     
            <!-- end item -->
            <!-- item -->
            <a class="px-4 py-2 block capitalize font-medium text-sm tracking-wide bg-white hover:bg-gray-200 hover:text-gray-900 transition-all duration-300 ease-in-out" href="#">
              <i class="fad fa-comment-alt-dots text-xs mr-1"></i> 
              chats
            </a>     
            <!-- end item -->
            <hr>
            <!-- item -->
            <a class="px-4 py-2 block capitalize font-medium text-sm tracking-wide bg-white hover:bg-gray-200 hover:text-gray-900 transition-all duration-300 ease-in-out" 
            href="{{ route('logout') }}"
            onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
              <i class="fad fa-user-times text-xs mr-1"></i> 
              log out
            </a>     
            <!-- end item -->
          </div>
        </div>
        <!-- end user -->

        <!-- notifcation -->
        <!-- end notifcation -->

        <!-- messages -->    
        <!-- end messages -->               


      </div>
      <!-- end right -->
    </div>
    <!-- end navbar content -->

  </div>
<!-- end navbar -->


<!-- strat wrapper -->
<div class="h-screen flex flex-row flex-wrap">
  
    <!-- start sidebar -->
  <div id="sideBar" class="relative flex flex-col flex-wrap bg-white border-r border-gray-300 p-6 flex-none w-64 md:-ml-64 md:fixed md:top-0 md:z-30 md:h-screen md:shadow-xl animated faster">
    

    <!-- sidebar content -->
    <div class="flex flex-col">

      <!-- sidebar toggle -->
      <div class="text-right hidden md:block mb-4">
        <button id="sideBarHideBtn">
          <i class="fad fa-times-circle"></i>
        </button>
      </div>
      <!-- end sidebar toggle -->

      <p class="uppercase text-xs text-gray-600 mb-4 tracking-wider">homes</p>

      <!-- link -->
      <a href="{{route('admin')}}" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
        <i class="fad fa-chart-pie text-xs mr-2"></i>                
        Analytics dashboard
      </a>
      <!-- end link -->

      <!-- link -->
      <a href="backend/./index-1.html" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
        <i class="fad fa-shopping-cart text-xs mr-2"></i>
        ecommerce dashboard
      </a>
      <!-- end link -->

      <p class="uppercase text-xs text-gray-600 mb-4 mt-4 tracking-wider">Management</p>

      <!-- link -->
      <a href="#" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
        <i class="fad fa-envelope-open-text text-xs mr-2"></i>
        Users
      </a>
      <!-- end link -->

      <!-- link -->
      <a href="#" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
        <i class="fad fa-comments text-xs mr-2"></i>
        Movies
      </a>
      <!-- end link -->

      <!-- link -->
      <a href="#" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
        <i class="fad fa-shield-check text-xs mr-2"></i>
        Movie Events
      </a>
      <!-- end link -->

      <!-- link -->
      <a href="#" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
        <i class="fad fa-calendar-edit text-xs mr-2"></i>
        Orders
      </a>
      <!-- end link -->

      <!-- link -->
      <a href="#" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
        <i class="fad fa-file-invoice-dollar text-xs mr-2"></i>
        Show Time
      </a>
      <!-- end link -->

      <!-- link -->
      <a href="#" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
        <i class="fad fa-folder-open text-xs mr-2"></i>
        Theaters
      </a>
      <!-- end link -->   
      
      <p class="uppercase text-xs text-gray-600 mb-4 mt-4 tracking-wider">UI Elements</p>

      <!-- link -->
      <a href="backend/./typography.html" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
        <i class="fad fa-text text-xs mr-2"></i>
        typography
      </a>
      <!-- end link -->

      <!-- link -->
      <a href="backend/alert.html" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
        <i class="fad fa-whistle text-xs mr-2"></i>
        alerts
      </a>
      <!-- end link -->
      

      <!-- link -->
      <a href="backend/buttons.html" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
        <i class="fad fa-cricket text-xs mr-2"></i>
        buttons
      </a>
      <!-- end link -->

      <!-- link -->
      <a href="#" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
        <i class="fad fa-box-open text-xs mr-2"></i>
        Content
      </a>
      <!-- end link -->

      <!-- link -->
      <a href="#" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
        <i class="fad fa-swatchbook text-xs mr-2"></i>
        colors
      </a>
      <!-- end link -->

      <!-- link -->
      <a href="#" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
        <i class="fad fa-atom-alt text-xs mr-2"></i>
        icons
      </a>
      <!-- end link -->

      <!-- link -->
      <a href="#" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
        <i class="fad fa-club text-xs mr-2"></i>
        card
      </a>
      <!-- end link -->

      <!-- link -->
      <a href="#" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
        <i class="fad fa-cheese-swiss text-xs mr-2"></i>
        Widgets
      </a>
      <!-- end link -->

      <!-- link -->
      <a href="#" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
        <i class="fad fa-computer-classic text-xs mr-2"></i>
        Components
      </a>
      <!-- end link -->
      
      

    </div>
    <!-- end sidebar content -->

  </div>
  <!-- end sidbar -->

  <!-- strat content -->
  <div class="bg-gray-100 flex-1 p-6 md:mt-16"> 

    <!-- congrats & summary -->
    <div class="grid grid-cols-3 lg:grid-cols-1 gap-5">
      <!-- congrats -->
<div class="card col-span-1">

    <div class="card-body h-full flex flex-col justify-between">

        <div>
            <h1 class="text-lg font-bold tracking-wide">name of the theater</h1>
            <p class="text-gray-600 mt-2">Most viewed this month</p>
        </div>
    
        <div class="flex flex-row mt-10 items-end">
    
            <div class="flex-1">
                <h1 class="font-extrabold text-4xl text-teal-400">{total viewed}</h1>
                <p class="mt-3 mb-4 text-xs text-gray-500">{percent overall}</p>
                <a href="#" class="btn-shadow py-3">
                  view time
                </a>
            </div>
    
            <div class="flex-1 ml-10 w-32 h-32 lg:w-auto lg:h-auto overflow-hidden">
                <img class="object-cover" src="{{asset('backend/img/congrats.svg')}}" alt="movie poster">
            </div>
    
        </div>

    </div>
    
</div>
<!-- end congrats -->
    <div class="card p-0 overflow-hidden col-span-2 lg:col-span-1 flex flex-row lg:flex-col">
      <div class="w-1/3 h-2/3 lg:w-full border-r border-gray-200">
        <!-- top -->
        <div class="p-5 border-b border-gray-200">
            <h2 class="font-bold text-lg mb-6">Top Views</h2>
            <div class="flex flex-row justify-between mb-3">
                <div class="">
                    <h4 class="text-gray-600 font-thin">{Movie 1}</h4>
                    <p class="text-gray-400 text-xs font-hairline">{note}</p>
                </div>
                <div class="text-sm font-medium">
                    <span class="text-red-500">250 Views</span> 
                </div>
            </div>
            <div class="flex flex-row justify-between mb-3">
              <div class="">
                  <h4 class="text-gray-600 font-thin">{Movie 2}</h4>
                  <p class="text-gray-400 text-xs font-hairline">{note}</p>
              </div>
              <div class="text-sm font-medium">
                  <span class="text-red-500">250 Views</span> 
              </div>
          </div>
            
          <div class="flex flex-row justify-between mb-3">
            <div class="">
                <h4 class="text-gray-600 font-thin">{Movie 3}</h4>
                <p class="text-gray-400 text-xs font-hairline">{note}</p>
            </div>
            <div class="text-sm font-medium">
                <span class="text-red-500">250 Views</span> 
            </div>
          </div>
      </div>
        <!-- end top -->
        <div class="p-5 ">
            <h2 class="font-bold text-lg mb-2">Total View</h2>
            <strong class="text-teal-400 font-extrabold text-xl">1999 Views</strong>

            <div class="bg-gray-300 h-2 rounded-full mt-2 relative">
            <div class="rounded-full bg-teal-400 h-full w-3/4 shadow-md"></div>
        </div>
        <!-- bottom -->
        
      <!-- end bottom -->
      </div>
      
    </div>
    <!-- left -->
    <div class="w-1/3 lg:w-full border-r border-gray-200">
        <!-- top -->
        <div class="p-5 border-b border-gray-200">
            <h2 class="font-bold text-lg mb-6">Top Revenue</h2>

            <div class="flex flex-row justify-between mb-3">
              <div class="">
                  <h4 class="text-gray-600 font-thin">{Movie  1}</h4>
                  <p class="text-gray-400 text-xs font-hairline">{note}</p>
              </div>
              <div class="text-sm font-medium">
                  <span class="text-red-500">250 Views</span> 
              </div>
          </div>

          <div class="flex flex-row justify-between mb-3">
            <div class="">
                <h4 class="text-gray-600 font-thin">{Movie  2}</h4>
                <p class="text-gray-400 text-xs font-hairline">{note}</p>
            </div>
            <div class="text-sm font-medium">
                <span class="text-red-500">250 Views</span> 
            </div>
        </div>
            
          <div class="flex flex-row justify-between mb-3">
            <div class="">
                <h4 class="text-gray-600 font-thin">{Movie  3}</h4>
                <p class="text-gray-400 text-xs font-hairline">{note}</p>
            </div>
            <div class="text-sm font-medium">
                <span class="text-red-500">250 Views</span> 
            </div>
        </div>
        </div>
        <!-- end top -->
        <!-- bottom -->
      
        <div class="p-5">
            <h2 class="font-bold text-lg mb-2">Total Revenue</h2>
            <strong class="text-teal-400 font-extrabold text-xl">$82,950.96</strong>

            <div class="bg-gray-300 h-2 rounded-full mt-2 relative">
              <div class="rounded-full bg-teal-400 h-full w-3/4 shadow-md"></div>
          </div>
        </div>
        <!-- end bottom -->
    </div>
    
    <!-- end left -->
<!-- left -->
<div class="w-1/3 lg:w-full">
        
  <!-- top -->
  <div class="p-5 border-b border-gray-200">
      <h2 class="font-bold text-lg mb-6">Top Rating</h2>

      <div class="flex flex-row justify-between mb-3">
        <div class="">
            <h4 class="text-gray-600 font-thin">{Movie 1}</h4>
            <p class="text-gray-400 text-xs font-hairline">{note}</p>
        </div>
        <div class="text-sm font-medium">
            <span class="text-red-500">5 stars</span> 
        </div>
    </div>

    <div class="flex flex-row justify-between mb-3">
      <div class="">
          <h4 class="text-gray-600 font-thin">{Movie 2}</h4>
          <p class="text-gray-400 text-xs font-hairline">{note}</p>
      </div>
      <div class="text-sm font-medium">
          <span class="text-red-500">5 stars</span> 
      </div>
  </div>
      
    <div class="flex flex-row justify-between mb-3">
      <div class="">
          <h4 class="text-gray-600 font-thin">{Movie 3}</h4>
          <p class="text-gray-400 text-xs font-hairline">{note}</p>
      </div>
      <div class="text-sm font-medium">
          <span class="text-red-500">5 stars</span> 
      </div>
  </div>
  </div>
  <!-- end top -->
  <!-- bottom -->
  <div class="p-5">
      <h2 class="font-bold text-lg mb-2">Highest Genre Rated</h2>
      <strong class="text-teal-400 font-extrabold text-xl">Action</strong>

      <div class="bg-gray-300 h-2 rounded-full mt-2 relative">
          <div class="rounded-full bg-teal-400 h-full w-3/4 shadow-md"></div>
      </div>
  </div>
  <!-- end bottom -->

</div>
<!-- end left -->
</div>
    </div>
    <!-- end congrats & summary -->
    <!-- status -->
    <div class="grid grid-cols-5 gap-5 mt-5 lg:grid-cols-2">

    <!-- status -->
    <div class="card col-span-1">
        <div class="card-body">
            <h5 class="uppercase text-xs tracking-wider font-extrabold">today</h5>
            <h1 class="capitalize text-lg mt-1 mb-1">$<span class="num-3"></span>  <span class="text-xs tracking-widest font-extrabold"> / <span class="num-2"></span> orders</span></h1>
            <p class="capitalize text-xs text-gray-500">( $<span class="num-2"></span> in the last year )</p>
        </div>
    </div>
    <!-- status -->

    <!-- status -->
    <div class="card col-span-1">
        <div class="card-body">
            <h5 class="uppercase text-xs tracking-wider font-extrabold">yesterday</h5>
            <h1 class="capitalize text-lg mt-1 mb-1">$<span class="num-3"></span>  <span class="text-xs tracking-widest font-extrabold"> / <span class="num-2"></span> orders</span></h1>
            <p class="capitalize text-xs text-gray-500">( $<span class="num-2"></span> in the last year )</p>
        </div>
    </div>
    <!-- status -->

    <!-- status -->
    <div class="card col-span-1">
        <div class="card-body">
            <h5 class="uppercase text-xs tracking-wider font-extrabold">last week</h5>
            <h1 class="capitalize text-lg mt-1 mb-1">$<span class="num-3"></span>  <span class="text-xs tracking-widest font-extrabold"> / <span class="num-2"></span> orders</span></h1>
            <p class="capitalize text-xs text-gray-500">( $<span class="num-2"></span> in the last year )</p>
        </div>
    </div>
    <!-- status -->

    <!-- status -->
    <div class="card col-span-1">
        <div class="card-body">
            <h5 class="uppercase text-xs tracking-wider font-extrabold">last month</h5>
            <h1 class="capitalize text-lg mt-1 mb-1">$<span class="num-3"></span>  <span class="text-xs tracking-widest font-extrabold"> / <span class="num-2"></span> orders</span></h1>
            <p class="capitalize text-xs text-gray-500">( $<span class="num-2"></span> in the last year )</p>
        </div>
    </div>
    <!-- status -->

    <!-- status -->
    <div class="card col-span-1 lg:col-span-2">
        <div class="card-body">
            <h5 class="uppercase text-xs tracking-wider font-extrabold">last 90-days</h5>
            <h1 class="capitalize text-lg mt-1 mb-1">$<span class="num-3"></span>  <span class="text-xs tracking-widest font-extrabold"> / <span class="num-2"></span> orders</span></h1>
            <p class="capitalize text-xs text-gray-500">( $<span class="num-2"></span> in the last year )</p>
        </div>
    </div>
    <!-- status -->
    
 
</div>
    <!-- end status -->

    <!-- best seller & traffic -->
    <div class="grid grid-cols-2 lg:grid-cols-1 gap-5 mt-5">
      <div class="card">

    <div class="card-body">
        <div class="flex flex-row justify-between items-center">
            <h1 class="font-extrabold text-lg">best sellers</h1>
            <a href="#" class="btn-gray text-sm">view all</a>
        </div>
    
        <table class="table-auto w-full mt-5 text-right">
    
            <thead>
                <tr>
                    <td class="py-4 font-extrabold text-sm text-left">product</td>
                    <td class="py-4 font-extrabold text-sm">price</td>
                    <td class="py-4 font-extrabold text-sm">sold</td>
                    <td class="py-4 font-extrabold text-sm">profit</td>
                </tr>
            </thead>
    
            <tbody>
    
                <!-- item -->
                <tr class="">
                    <td class="py-4 text-sm text-gray-600 flex flex-row items-center text-left">
                        <div class="w-8 h-8 overflow-hidden mr-3">
                            <img src="{{asset('backend/img/sneakers.svg" class="object-cover')}}">
                        </div>
                        Sneakers and Tennis 
                    </td>
                    <td class="py-4 text-xs text-gray-600">$ <span class="num-2"></span></td>
                    <td class="py-4 text-xs text-gray-600"><span class="num-3"></span></td>
                    <td class="py-4 text-xs text-gray-600">$ <span class="num-4"></span></td>
                </tr>
                <!-- end item -->
    
                <!-- item -->
                <tr class="">
                    <td class="py-4 text-sm text-gray-600 flex flex-row items-center">
                        <div class="w-8 h-8 overflow-hidden mr-3">
                            <img src="{{asset('backend/img/socks.svg" class="object-cover')}}">
                        </div>
                        Crazy Socks & Graphic Socks for Men
                    </td>
                    <td class="py-4 text-xs text-gray-600">$ <span class="num-2"></span></td>
                    <td class="py-4 text-xs text-gray-600"><span class="num-3"></span></td>
                    <td class="py-4 text-xs text-gray-600">$ <span class="num-4"></span></td>
                </tr>
                <!-- end item -->
    
                <!-- item -->
                <tr class="">
                    <td class="py-4 text-sm text-gray-600 flex flex-row items-center">
                        <div class="w-8 h-8 overflow-hidden mr-3">
                            <img src="{{asset('backend/img/soccer.svg" class="object-cover')}}">
                        </div>
                        Adidas Soccer Ball
                    </td>
                    <td class="py-4 text-xs text-gray-600">$ <span class="num-2"></span></td>
                    <td class="py-4 text-xs text-gray-600"><span class="num-3"></span></td>
                    <td class="py-4 text-xs text-gray-600">$ <span class="num-4"></span></td>
                </tr>
                <!-- end item -->
    
                <!-- item -->
                <tr class="">
                    <td class="py-4 text-sm text-gray-600 flex flex-row items-center">
                        <div class="w-8 h-8 overflow-hidden mr-3">
                            <img src="{{asset('backend/img/food.svg" class="object-cover')}}">
                        </div>
                        Best Chocolate Chip Cookies
                    </td>
                    <td class="py-4 text-xs text-gray-600">$ <span class="num-2"></span></td>
                    <td class="py-4 text-xs text-gray-600"><span class="num-3"></span></td>
                    <td class="py-4 text-xs text-gray-600">$ <span class="num-4"></span></td>
                </tr>
                <!-- end item -->
    
            </tbody>
    
        </table>
    
    </div>
</div>
      <div class="card">    

    <div class="card-body">
        <h2 class="font-bold text-lg mb-10">Recent Orders</h2>
    
    <!-- start a table -->
    <table class="table-fixed w-full">
        
        <!-- table head -->
        <thead class="text-left">
            <tr>
                <th class="w-1/2 pb-10 text-sm font-extrabold tracking-wide">customer</th>
                <th class="w-1/4 pb-10 text-sm font-extrabold tracking-wide text-right">Product</th>
                <th class="w-1/4 pb-10 text-sm font-extrabold tracking-wide text-right">Invoice</th>
                <th class="w-1/4 pb-10 text-sm font-extrabold tracking-wide text-right">price</th>
                <th class="w-1/4 pb-10 text-sm font-extrabold tracking-wide text-right">status</th>
            </tr>
        </thead>
        <!-- end table head -->

        <!-- table body -->
        <tbody class="text-left text-gray-600">

            <!-- item -->
            <tr>
                <!-- name -->
                <th class="w-1/2 mb-4 text-xs font-extrabold tracking-wider flex flex-row items-center">
                    <div class="w-8 h-8 overflow-hidden rounded-full">
                        <img src="{{asset('backend/img/user2.jpg" class="object-cover')}}">
                    </div>
                    <p class="ml-3 name-1">user name</p>                    
                </th>
                <!-- name -->
                
                <!-- product -->
                <th class="w-1/4 mb-4 text-xs font-extrabold tracking-wider text-right">Nike Sport</th>
                <!-- product -->

                <!-- invoice -->
                <th class="w-1/4 mb-4 text-xs font-extrabold tracking-wider text-right">#<span class="num-4"></span></th>
                <!-- invoice -->

                <!-- price -->
                <th class="w-1/4 mb-4 text-xs font-extrabold tracking-wider text-right">$<span class="num-2"></span></th>
                <!-- price -->

                <!-- status -->
                <th class="w-1/4 mb-4 text-xs font-extrabold tracking-wider text-right">shipped</th>
                <!-- status -->

            </tr>
            <!-- item -->


            <!-- item -->
            <tr>
                <!-- name -->
                <th class="w-1/2 mb-4 text-xs font-extrabold tracking-wider flex flex-row items-center ">
                    <div class="w-8 h-8 overflow-hidden rounded-full">
                        <img src="{{asset('backend/img/user3.jpg" class="object-cover')}}">
                    </div>
                    <p class="ml-3 name-1">user name</p>                    
                </th>
                <!-- name -->
                
                <!-- product -->
                <th class="w-1/4 mb-4 text-xs font-extrabold tracking-wider text-right">Nike Sport</th>
                <!-- product -->

                <!-- invoice -->
                <th class="w-1/4 mb-4 text-xs font-extrabold tracking-wider text-right">#<span class="num-4"></span></th>
                <!-- invoice -->

                <!-- price -->
                <th class="w-1/4 mb-4 text-xs font-extrabold tracking-wider text-right">$<span class="num-2"></span></th>
                <!-- price -->

                <!-- status -->
                <th class="w-1/4 mb-4 text-xs font-extrabold tracking-wider text-right">shipped</th>
                <!-- status -->

            </tr>
            <!-- item -->


            <!-- item -->
            <tr>
                <!-- name -->
                <th class="w-1/2 mb-4 text-xs font-extrabold tracking-wider flex flex-row items-center ">
                    <div class="w-8 h-8 overflow-hidden rounded-full">
                        <img src="{{asset('backend/img/user2.jpg" class="object-cover')}}">
                    </div>
                    <p class="ml-3 name-1">user name</p>                    
                </th>
                <!-- name -->
                
                <!-- product -->
                <th class="w-1/4 mb-4 text-xs font-extrabold tracking-wider text-right">Nike Sport</th>
                <!-- product -->

                <!-- invoice -->
                <th class="w-1/4 mb-4 text-xs font-extrabold tracking-wider text-right">#<span class="num-4"></span></th>
                <!-- invoice -->

                <!-- price -->
                <th class="w-1/4 mb-4 text-xs font-extrabold tracking-wider text-right">$<span class="num-2"></span></th>
                <!-- price -->

                <!-- status -->
                <th class="w-1/4 mb-4 text-xs font-extrabold tracking-wider text-right">shipped</th>
                <!-- status -->

            </tr>
            <!-- item -->

            <!-- item -->
            <tr>
                <!-- name -->
                <th class="w-1/2 mb-4 text-xs font-extrabold tracking-wider flex flex-row items-center ">
                    <div class="w-8 h-8 overflow-hidden rounded-full">
                        <img src="{{asset('backend/img/user1.jpg" class="object-cover')}}">
                    </div>
                    <p class="ml-3 name-1">user name</p>                    
                </th>
                <!-- name -->
                
                <!-- product -->
                <th class="w-1/4 mb-4 text-xs font-extrabold tracking-wider text-right">Nike Sport</th>
                <!-- product -->

                <!-- invoice -->
                <th class="w-1/4 mb-4 text-xs font-extrabold tracking-wider text-right">#<span class="num-4"></span></th>
                <!-- invoice -->

                <!-- price -->
                <th class="w-1/4 mb-4 text-xs font-extrabold tracking-wider text-right">$<span class="num-2"></span></th>
                <!-- price -->

                <!-- status -->
                <th class="w-1/4 mb-4 text-xs font-extrabold tracking-wider text-right">shipped</th>
                <!-- status -->

            </tr>
            <!-- item -->

            <!-- item -->
            <tr>
                <!-- name -->
                <th class="w-1/2 mb-4 text-xs font-extrabold tracking-wider flex flex-row items-center ">
                    <div class="w-8 h-8 overflow-hidden rounded-full">
                        <img src="{{asset('backend/img/user3.jpg" class="object-cover')}}">
                    </div>
                    <p class="ml-3 name-1">user name</p>                    
                </th>
                <!-- name -->
                
                <!-- product -->
                <th class="w-1/4 mb-4 text-xs font-extrabold tracking-wider text-right">Nike Sport</th>
                <!-- product -->

                <!-- invoice -->
                <th class="w-1/4 mb-4 text-xs font-extrabold tracking-wider text-right">#<span class="num-4"></span></th>
                <!-- invoice -->

                <!-- price -->
                <th class="w-1/4 mb-4 text-xs font-extrabold tracking-wider text-right">$<span class="num-2"></span></th>
                <!-- price -->

                <!-- status -->
                <th class="w-1/4 mb-4 text-xs font-extrabold tracking-wider text-right">shipped</th>
                <!-- status -->

            </tr>
            <!-- item -->            

            


        </tbody>
        <!-- end table body -->

    </table>
    <!-- end a table -->
    </div>

</div> 
          
    </div>
    <!-- end best seller & traffic -->
        

  </div>
  <!-- end content -->

</div>
<!-- end wrapper -->

<!-- script -->
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script src="{{asset('backend/js/scripts.js')}}"></script>
<!-- end script -->

</body>
</html>
