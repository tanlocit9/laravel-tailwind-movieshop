<!-- script -->
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script src="js/scripts.js"></script>
<!-- end script -->

</body>
</html><?php /**PATH C:\Users\Admin\Desktop\Laravel\movie-shop\resources\views/backend/base/end.blade.php ENDPATH**/ ?>