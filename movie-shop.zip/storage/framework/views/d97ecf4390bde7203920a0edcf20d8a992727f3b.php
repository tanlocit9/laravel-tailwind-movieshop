

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 pt-16">
    <div class="popular-movies">
        <h2 class="uppercase tracking-wider text-orange-500 text-lg text-semibold">
            Manage Users
        </h2>
    <div/>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\Laravel\movie-shop\resources\views/backend/users.blade.php ENDPATH**/ ?>