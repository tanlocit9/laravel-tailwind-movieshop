<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Admin</title>
    <link rel="stylesheet" href="/css/app.css">
</head>
<body class="font-sans bg-gray-900 text-white">
    <nav class="border-b border-gray-800">
        <div class="container mx-auto flex flex-col md:flex-row items-center justify-between px-4 py-6">
            <ul class="flex flex-col md:flex-row items-center">
                <li>
                    <a href="#" class="text-2xl text-red-500 hover:text-gray-300">Admin</a>
                </li>
                <li class="md:ml-16 mt-3 md:mt-0">
                    <a href="#" class="hover:text-gray-300">Films</a>
                </li>
                <li class="md:ml-6 mt-3 md:mt-0">
                    <a href="#" class="hover:text-gray-300">Tickets</a>
                </li>
                <li class="md:ml-6 mt-3 md:mt-0">
                    <a href="#" class="hover:text-gray-300">Actor</a>
                </li>
                <li class="md:ml-6 mt-3 md:mt-0">
                    <a href="#" class="hover:text-gray-300">Genres</a>
                </li>
                <li class="md:ml-6 mt-3 md:mt-0">
                    <a href="#" class="hover:text-gray-300">Orders</a>
                </li>
                <li class="md:ml-6 mt-3 md:mt-0">
                    <a href="#" class="hover:text-gray-300">Theaters</a>
                </li>
                <li class="md:ml-6 mt-3 md:mt-0">
                    <a href="#" class="hover:text-gray-300">Aticles</a>
                </li>
                <li class="md:ml-6 mt-3 md:mt-0">
                    <a href="<?php echo e(route('manage_users')); ?>" class="hover:text-gray-300">Users</a>
                </li>
            </ul>
        <div/>
    <nav/>

    <div >
        <div >
            <h2 >
                Manage Users
            </h2>
        <div/>
    </div>
</body>
</html><?php /**PATH C:\Users\Admin\Desktop\Laravel\movie-shop\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>